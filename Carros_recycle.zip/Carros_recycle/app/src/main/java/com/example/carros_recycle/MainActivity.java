package com.example.carros_recycle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Adapter;
import android.widget.ArrayAdapter;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView RvMain;
    private ArrayList<Carros> ListSeries;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cargardatosiniciales();

        RvMain = findViewById(R.id.rv_carro);
        RvMain.setLayoutManager(new LinearLayoutManager(this));
        AdaptadorPersonalizado adaptador = new AdaptadorPersonalizado(ListSeries);

        RvMain.setAdapter(adaptador);



    }

    private void cargardatosiniciales() {
        ListSeries = new ArrayList<>();

        Carros carro1 = new Carros("ONIX", "Marca: Chevrolet\nHP: 500","https://th.bing.com/th/id/R.795d673fb6762bddd99bff90ed89fe7f?rik=kjznKxR2R%2fxWbQ&pid=ImgRaw&r=0");
        Carros carro2 = new Carros("Twingo", "Marca: Renault\nHP: 200","https://th.bing.com/th/id/OIP.tIsD5HHWo7dOU0jMUYrSHAHaE6?pid=ImgDet&rs=1");
        Carros carro3 = new Carros("MX5", "Marca: Mazda\nHP: 800","https://th.bing.com/th/id/R.66c496a32d1942451ab8d4fe29f9d626?rik=ZrIjrvY4H4Lk8w&pid=ImgRaw&r=0");
        ListSeries.add(carro1);
        ListSeries.add(carro2);
        ListSeries.add(carro3);
    }
}