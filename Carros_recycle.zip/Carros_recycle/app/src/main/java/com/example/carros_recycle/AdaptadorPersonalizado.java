package com.example.carros_recycle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class AdaptadorPersonalizado extends RecyclerView.Adapter<AdaptadorPersonalizado.ViewHolder> {

    ArrayList<Carros> listadoDatos;

    public AdaptadorPersonalizado(ArrayList<Carros> listadoDatos) {
        this.listadoDatos = listadoDatos;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View vista = LayoutInflater.from(parent.getContext()).inflate(R.layout.itemrecyclercarro, parent, false);
        return new ViewHolder(vista);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.cargarDatos(listadoDatos.get(position));
    }

    @Override
    public int getItemCount() {
        return listadoDatos.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView titulo, descripcion;
        ImageView ivPrincipal;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            titulo = itemView.findViewById(R.id.tv_tit1);
            descripcion = itemView.findViewById(R.id.tv_des1);
            ivPrincipal = itemView.findViewById(R.id.img1);
        }

        public void cargarDatos(Carros serie) {
            titulo.setText(serie.getNombre());
            descripcion.setText(serie.getDescripcion());
            //ivPrincipal.setImageResource();
            Picasso.get()
                    .load(serie.getURLimg())
                    .resize(300, 300)
                    .centerCrop()
                    .error(R.drawable.ic_launcher_background)
                    .into(ivPrincipal);
        }
    }
}
