package com.example.carros_recycle;

public class Carros {
    private String nombre, descripcion, URLimg;

    //CONSTRUCTOR
    public Carros(String nombre, String descripcion, String URLimg) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.URLimg = URLimg;
    }
    //GETTERS AND SETTERS
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getURLimg() {
        return URLimg;
    }

    public void setURLimg(String URLimg) {
        this.URLimg = URLimg;
    }
}
